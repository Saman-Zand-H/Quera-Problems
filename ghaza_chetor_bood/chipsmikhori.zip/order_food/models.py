from django.db import models
from django_comments.moderation import CommentModerator, moderator
from django_comments.forms import CommentForm
from django import forms
from django_comments.signals import comment_was_posted
from django.contrib import messages


class Food(models.Model):
    name = models.CharField(max_length=50)
    description = models.CharField(max_length=400)
    price = models.IntegerField()
    

class Form(CommentForm):
    comment = forms.CharField(widget=forms.TextInput(), required=True)
    

class FoodModerator(CommentModerator):
    def allow(self, comment, content_object, request):
        return request.user.is_authenticated
    
    def form(self, comment_form):
        comment_form = Form()
        return comment_form
    

moderator.register(Food, FoodModerator)
    
    
def signal_message(sender, comment, request, **kwargs):
    messages.success(request, "your comment successfully submitted.")


comment_was_posted.connect(signal_message)
