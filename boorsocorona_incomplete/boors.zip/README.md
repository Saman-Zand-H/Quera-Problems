# Code Cup django Q2

```python
def magic(python):
    return f'web + python + fun'

print(magic('python'))
```
*`Django`*
