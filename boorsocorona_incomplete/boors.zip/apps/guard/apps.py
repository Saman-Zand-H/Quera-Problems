from django.apps import AppConfig


class GuardConfig(AppConfig):
    name = 'apps.guard'
