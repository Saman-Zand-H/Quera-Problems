from .base import *

DEBUG = config('DEBUG_VALUE', False)
