from django.apps import AppConfig


class DoobConfig(AppConfig):
    name = 'doob'
